export class Employ {
    public empId : number; 
    public empName : string; 
    public empPhone : string; 
    public empEmail : string; 
    public empDept : string; 
    public empJoinDate : string; 
    public empMgrId : number; 
    public empLeaveBal : number;
}
