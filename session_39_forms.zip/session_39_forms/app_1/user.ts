export class User {
    username :string;
    gender: string;
    isMarried : string;
    isTCAccepted :boolean;
    constructor(){
    }
}
