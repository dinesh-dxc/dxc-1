package com.dxc.project;

public class StudentException extends Exception {
	
	public StudentException() {
	}
	
	public StudentException(String error) {
		super(error);
	}
}
