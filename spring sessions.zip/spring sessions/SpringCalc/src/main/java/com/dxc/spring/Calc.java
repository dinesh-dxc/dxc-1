package com.dxc.spring;

public interface Calc {

	int sum();
	int sub();
	int mult();
	
}
