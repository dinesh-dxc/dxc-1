package com.dxc.spring;

public interface Hello {

	String sayHello(String name);
}
