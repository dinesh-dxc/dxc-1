package com.dxc.junit;

public class Demo {
	
	
	public int sum(int a, int b) {
		return a+b;
	} 
	
	public String sayHello() {
		return "Welcome to Junit...";
	}
}
