package com.dxc.helloservice;

public class Hello {

	public String sayHello() {
		return "Welcome to Webservices...";
	}
}
