package dxc.WebserviceDemo;

public class Hello {

	public String sayHello() {
		return "Welcome to Java Webservices...";
	}
}
