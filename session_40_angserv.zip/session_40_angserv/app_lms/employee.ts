export class Employee {
    constructor() {}
    public  empId : number;
	public  empName : string;
	public empEmail : string;
	public empMobile : string;
	public empDptName : string;
	public empDateOfJoin : Date ;
	public  empMgrId : number;
	public empLeaveBalance : number;
}
