package com.dxc.cms;

import java.sql.SQLException;

public class Test1 {
	public static void main(String[] args) {
//		Menu[] list;
//		try {
//			list = new MenuDAO().showMenu();
//			for (Menu menu : list) {
//				System.out.println(menu);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		try {
			int res = new CustomerDAO().authenticate("krishnak","chennai@123");
			System.out.println(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
