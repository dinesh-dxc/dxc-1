package com.dxc.col;

public class StrEx {
	public static void main(String[] args) {
		String s1 = "Pranjali";
		String s2 = "Raj";
		System.out.println(s1.compareTo(s2));
	}
}
