package com.hcl.project;

public class StudentException extends Exception {

	public StudentException(String error) {
		super(error);
	}
}
