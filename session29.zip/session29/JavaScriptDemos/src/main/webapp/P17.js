/**
 * 
 */
function show() {
	var myArray = [	"Today We are learning JavaScript",
		"Next Topic SpringHibernateNate Integration",
		"Weekend Project will be given for Practice"
		];
	document.getElementById("p1").innerHTML=myArray[0];
	document.getElementById("p2").innerHTML=myArray[1];
	document.getElementById("p3").innerHTML=myArray[2];
}
