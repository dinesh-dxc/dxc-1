package com.dxc.welcome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployShowApplication.class, args);
	}

}
