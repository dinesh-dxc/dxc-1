package com.dxc.welcome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
